/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laberinto;

import java.util.*;

/**
 *@version 10/08/2016
 * @author Sang Woo Shin Ji, Diego Ricardo Valdez Cabrera, Ramón Andres Samayoa, Jorge Mario Lara 
 */
public class Mapa {
    
    /**
     * atributos
     * estados
     */
    private List<String> estados;
    
    public Mapa(){
        estados= new ArrayList<>();
    }
    //empuja valores dentro de la lista

    /**
     *
     * @param x: String[]
     * Se mete las direcciones del sensor
     */
        public void pushLista(String[] x){
        String y=x[0]+" "+x[1]+" "+x[2]+" "+x[3];
        estados.add(y);
    }
    //saca y borra un valor en la lista.

    /**
     *
     * @return x : String []
     * Se sacan las direcciones del sensor
     */
        public String[] popLista(){
        int dir = estados.size();
        dir=dir -1;
        String y = estados.remove(dir);
        String[] x= y.split(" ");
        return x;
    }
}
